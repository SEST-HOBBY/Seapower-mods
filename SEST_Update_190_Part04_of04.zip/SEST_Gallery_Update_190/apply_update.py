#!/usr/bin/env python3
"""Apply the photograph update to a new offline-gallery folder using Python 3."""
from pathlib import Path, PurePosixPath
import argparse, hashlib, json, shutil, sys

def digest(p):
    h=hashlib.sha256()
    with p.open('rb') as f:
        for b in iter(lambda:f.read(1024*1024),b''):h.update(b)
    return h.hexdigest()

def safe(root,name):
    q=PurePosixPath(name)
    if q.is_absolute() or '..' in q.parts or '\\' in name:raise ValueError('Unsafe path: '+name)
    p=root.joinpath(*q.parts)
    if not p.resolve().is_relative_to(root.resolve()):raise ValueError('Escaping path: '+name)
    return p

def main():
    ap=argparse.ArgumentParser(description=__doc__)
    ap.add_argument('--base',type=Path,required=True,help='Existing SEST_Modernised_Collection_Gallery folder')
    ap.add_argument('--output',type=Path,required=True,help='New output folder; must not already exist')
    a=ap.parse_args();root=Path(__file__).resolve().parent;payload=root/'payload'
    base=a.base.resolve();out=a.output.resolve()
    if not (base/'manifest.json').is_file():raise ValueError('Base gallery manifest not found; extract the earlier gallery first.')
    if out.exists():raise ValueError('Output already exists. Choose a new staging directory.')
    if out.is_relative_to(base) or base.is_relative_to(out):raise ValueError('Output and base must be separate directory trees.')
    if out.is_relative_to(root) or root.is_relative_to(out):raise ValueError('Output must be separate from the update package.')
    m=json.loads((root/'PAYLOAD_MANIFEST.json').read_text(encoding='utf-8'))
    files=m['files'];actual={str(p.relative_to(payload)) for p in payload.rglob('*') if p.is_file()}
    if set(files)!=actual:raise ValueError('Payload file set differs from the manifest; a part is missing or unexpected files were added.')
    for name,h in files.items():
        p=safe(payload,name)
        if p.is_symlink() or digest(p)!=h:raise ValueError('Payload checksum mismatch: '+name)
    bm=json.loads((base/'manifest.json').read_text(encoding='utf-8'))
    assets={x['asset_id']:x for x in bm['assets']}
    if {k:v['sha256'] for k,v in assets.items()}!=m['baseline_catalogue_assets']:
        raise ValueError('Base catalogue differs from the reviewed version. Preserve later work and reconcile manually; do not force this update.')
    for aid,h in m['baseline_catalogue_assets'].items():
        p=safe(base,assets[aid]['file'])
        if not p.is_file() or p.is_symlink() or digest(p)!=h:raise ValueError('Base photograph missing or changed: '+aid)
    for name,h in m['baseline_metadata'].items():
        p=safe(base,name)
        if not p.is_file() or digest(p)!=h:raise ValueError('Base metadata changed: '+name+'; reconcile manually to preserve newer work.')
    for name,h in m['unchanged_visuals'].items():
        p=safe(base,name)
        if not p.is_file() or digest(p)!=h:raise ValueError('Base flag/loading asset missing or changed: '+name)
    if any(p.is_symlink() for p in base.rglob('*')):raise ValueError('Base gallery contains symlinks; inspect before copying.')
    shutil.copytree(base,out);shutil.copytree(payload,out,dirs_exist_ok=True)
    for name,h in files.items():
        if digest(safe(out,name))!=h:raise ValueError('Copied payload checksum mismatch: '+name)
    print(json.dumps({'output':str(out),'replaced':m['summary']['replacement_images'],'added':m['summary']['added_images'],'installed_mods':m['summary']['installed_mods'],'base_preserved':True,'game_files_changed':False},indent=2))

if __name__=='__main__':
    try:main()
    except (ValueError,OSError,KeyError) as e:print('UPDATE STOPPED: '+str(e),file=sys.stderr);sys.exit(1)
