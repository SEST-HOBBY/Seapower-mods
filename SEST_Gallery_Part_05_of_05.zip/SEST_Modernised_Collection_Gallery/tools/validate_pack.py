"""Validate the gallery offline; use from the extracted ZIP with Python 3."""
from pathlib import Path
import json,hashlib,sys
R=Path(__file__).resolve().parents[1]
d=json.loads((R/'manifest.json').read_text(encoding='utf-8'))
errors=[];assets={}
for a in d['assets']:
    aid=a['asset_id'];p=R/a['file']
    if aid in assets:errors.append('Duplicate asset ID: '+aid)
    assets[aid]=a
    if not p.is_file():errors.append('Missing image: '+a['file']);continue
    if hashlib.sha256(p.read_bytes()).hexdigest()!=a['sha256']:errors.append('Changed image: '+a['file'])
    for field in ['creator','license','source_page','source_file_title']:
        if not a.get(field):errors.append(aid+': missing '+field)
    if not (R/'source_records'/f'{aid}.json').is_file():errors.append('Missing source record: '+aid)
seen=set()
for e in d['entries']+d['systems']:
    if e['entry_id'] in seen:errors.append('Duplicate entry ID: '+e['entry_id'])
    seen.add(e['entry_id'])
    if e['asset_id'] and e['asset_id'] not in assets:errors.append('Unknown asset: '+e['entry_id'])
    if e.get('image_file') and not (R/e['image_file']).is_file():errors.append('Broken image path: '+e['entry_id'])
for p in ['gallery.html','gallery.js','catalogue.js','PHOTO_CREDITS.txt','CLAUDE_HANDOFF.md','visual_overhaul.html','VISUAL_CREDITS.txt','VISUAL_OVERHAUL_HANDOFF.md']:
    if not (R/p).is_file():errors.append('Missing file: '+p)
v=json.loads((R/'visuals/manifest.json').read_text(encoding='utf-8'))
for a in v['flags']+v['loading']:
    if not a.get('file'):continue
    for key,hashkey in [('file','sha256'),('png_file','png_sha256')]:
        if not a.get(key):continue
        p=R/a[key]
        if not p.is_file():errors.append('Missing visual: '+a[key])
        elif hashlib.sha256(p.read_bytes()).hexdigest()!=a[hashkey]:errors.append('Changed visual: '+a[key])
    for key in ['creator','license','source_page']:
        if not a.get(key):errors.append(a.get('id','visual')+': missing '+key)
for a in v['loading']:
    if a['source_asset_id'] not in assets:errors.append('Loading photo missing from main catalogue: '+a['id'])
for p in R.rglob('*'):
    if p.is_file() and 'generated_images' in str(p):errors.append('Excluded AI image path present: '+str(p))
print(json.dumps({'photos':len(assets),'physical_definitions':len(d['entries']),'systems':len(d['systems']),'mods':len(d['mods']),'flag_assets':sum(bool(a.get('file')) for a in v['flags']),'loading_backgrounds':len(v['loading']),'errors':errors},indent=2))
sys.exit(bool(errors))
