"""Validate quality grades, task coverage and asset links without dependencies."""
from pathlib import Path
from collections import Counter
import hashlib,json,sys
R=Path(__file__).resolve().parents[1]
m=json.loads((R/'manifest.json').read_text(encoding='utf-8'))
v=json.loads((R/'visuals/manifest.json').read_text(encoding='utf-8'))
a=json.loads((R/'data/image_quality_audit.json').read_text(encoding='utf-8'))
queue=json.loads((R/'data/manual_replacement_queue.json').read_text(encoding='utf-8'))['queue']
errors=[]
expected={'photo:'+x['asset_id']:x for x in m['assets']}
expected.update({'loading:'+x['id']:x for x in v['loading']})
rows=a['photos']+a['loading'];seen=set()
for r in rows:
    aid=r['audit_id']
    if aid in seen:errors.append('Duplicate audit ID: '+aid)
    seen.add(aid)
    if aid not in expected:errors.append('Unknown audit ID: '+aid);continue
    src=expected[aid]
    if r['file']!=src['file']:errors.append('Path mismatch: '+aid)
    p=R/r['file']
    if not p.is_file():errors.append('Missing asset: '+r['file'])
    elif hashlib.sha256(p.read_bytes()).hexdigest()!=r['sha256']:errors.append('Asset bytes changed: '+aid)
    if r['quality_grade'] not in 'ABCD' or r['subject_visibility_grade'] not in 'ABCD':errors.append('Invalid grade: '+aid)
    if r['priority'] not in ['P1','P2','P3','P4']:errors.append('Invalid priority: '+aid)
    for f in ['reason','replacement_brief','review_basis','source_page','creator','license']:
        if not r.get(f):errors.append('Missing '+f+': '+aid)
    for f in ['quality_grade','subject_visibility_grade','priority']:
        if src.get('quality_review',{}).get(f)!=r[f]:errors.append('Manifest grade mismatch: '+aid+' '+f)
if seen!=set(expected):errors.append('Audit does not cover the complete photo/loading inventory')
ranked=sorted(rows,key=lambda r:r['queue_rank'])
if [r['queue_rank'] for r in ranked]!=list(range(1,len(rows)+1)):errors.append('Invalid queue ranks')
if queue!=[r for r in ranked if r['priority'] in ['P1','P2']]:errors.append('Replacement queue is incomplete or out of order')
s=a['summary']
for field,actual in [('total_reviewed',len(rows)),('photo_count',len(a['photos'])),('loading_count',len(a['loading'])),('quality_grade_counts',dict(Counter(r['quality_grade'] for r in rows))),('visibility_grade_counts',dict(Counter(r['subject_visibility_grade'] for r in rows))),('priority_counts',dict(Counter(r['priority'] for r in rows)))]:
    if s[field]!=actual:errors.append('Summary mismatch: '+field)
if json.loads((R/'data/image_quality_summary.json').read_text())!=s:errors.append('Standalone summary mismatch')
for filename in ['IMAGE_QUALITY_REVIEW.html','QUALITY_REVIEW_GUIDE.txt','CLAUDE_START_HERE.txt']:
    if not (R/filename).is_file():errors.append('Missing handoff: '+filename)
print(json.dumps({'reviewed_images':len(rows),'replacement_tasks':len(queue),'photo_quality':s['quality_grade_counts'],'priorities':s['priority_counts'],'errors':errors},indent=2))
sys.exit(bool(errors))
